

<h1 align="center">𝗞𝗘𝗜𝗧𝗛-𝗠𝗗</h1>

<h1 align="center">Survival is winning, frankline everything else is bullshit, fairy tales spun by people afraid to look life in the eye, do whatever it takes kid, survive 😏🙏</h1>


<div style="text-align: center;">
  <a href="https://ibb.co/N6NMDtn">
    <img src="https://i.imgur.com/XlQIFIF.jpeg" alt="01" border="0" /></a>
  </a>

  </a>
  <hr style="margin-top: 20px; margin-bottom: 20px;"/>
</div>

<table align="center" cellpadding="10" border="1">
  <tr>
    <td align="center">
      <b>FORK</b><br>
      Fork the repository to customize and use the bot for your needs.
      <br><br>
      <a href="https://github.com/keithkeizzah/KEITH-MD/fork">
        <img src="https://img.shields.io/badge/FORK-purple" alt="FORK KEITH" width="150">
      </a>
    </td>
    <td align="center">
      <b>SESSION</b><br>
      Link your session ID to start using the bot. Follow steps if issues arise.
      <br><br>
      <a href="https://keith-session.onrender.com/pair">
        <img src="https://img.shields.io/badge/Pair%20session%20code-white" alt="𝐏𝐚𝐢𝐫%20𝐬𝐞𝐬𝐬𝐢𝐨𝐧%20𝐜𝐨𝐝𝐞" width="300">
      </a>
    </td>
  </tr>
  <tr>
    <td align="center">
      <b>KEITH APIs</b><br>
      Visit our website for Keith APIs and integrations though still updating.
      <br><br>
      <a href="https://apis-keith.vercel.app/">
        <img src="https://img.shields.io/badge/Visit%20KEITH%20APIs-blue" alt="Visit KEITH APIs" width="200">
      </a>
    </td>
    <td align="center">
      <b>DEPLOY</b><br>
      Deploy the bot to your server or platform of choice using the button below.
      <br><br>
      <a href="https://dashboard.heroku.com/new?button-url=https://github.com/keithkeizzah/KEITH-MD&template=https://github.com/keithkeizzah/KEITH-MD.git">
        <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy to Heroku">
      </a>
    </td>
  </tr>
</table>


<p align="center">
  <i>This bot is still under maintenance, and sometimes APIs might be down. Apologies for the inconvenience; we are working to make it better!</i>
</p>

<p align="center">
  <i>Due to recent WhatsApp updates and issues with Baileys, your bot may fail to start. Here are the steps to follow if you encounter this problem:</i>
</p>

<ol>
  <li>Relink your session ID by changing the session to the app you deployed.</li>
  <li>If that doesn't work, try updating your WhatsApp.</li>
  <li>If the issue persists, don’t give up! Just keep relinking the session until it works. 🙏🙏</li>
</ol>

<h1 align="center">Thanks to our loyal folowers</h1>

<p align="center">
  <a href="https://github.com/Keithkeizzah/KEITH-MD/stargazers">
    <img src="http://reporoster.com/stars/dark/Keithkeizzah/KEITH-MD" alt="Stargazers repo roster for @Keithkeizzah/KEITH-MD">
  </a>
</p>

<p align="center">
  <a href="https://github.com/Keithkeizzah/KEITH-MD/network/members">
    <img src="http://reporoster.com/forks/dark/Keithkeizzah/KEITH-MD" alt="Forkers repo roster for @Keithkeizzah/KEITH-MD">
  </a>
</p>

